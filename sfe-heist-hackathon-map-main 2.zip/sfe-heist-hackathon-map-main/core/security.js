import * as THREE from '../vendor/three.module.js';
import { overlapsCollider } from './controller.js';

const CAMERA_PLAN = [
    { id: 'street-eye', floor: 'L1', position: [0, 3.12, 17.55], yaw: 0.02, sweep: .35, phase: .4, range: 12, fov: .52 },
    { id: 'atrium-eye', floor: 'L1', position: [-4.55, 3.82, 8.4], yaw: -.58, sweep: .72, phase: 1.3, range: 13, fov: .48 },
    { id: 'ops-eye', floor: 'L1', position: [15.1, 3.12, -5.6], yaw: -Math.PI / 2, sweep: .58, phase: 2.4, range: 12, fov: .5 },
    { id: 'lift-eye', floor: 'B1', position: [3.2, -1.3, -6.9], yaw: 0, sweep: .46, phase: .9, range: 11, fov: .5 },
    { id: 'reserve-eye', floor: 'B1', position: [0, -.55, -10.65], yaw: Math.PI, sweep: .68, phase: 2.1, range: 12, fov: .48 },
];

/** A small, visible sensor network that drives the trace meter and Ghostline software. */
export function createSecurityNetwork(world) {
    const sensors = CAMERA_PLAN.map(plan => {
        const group = new THREE.Group();
        group.name = `Security camera ${plan.id}`;
        group.position.set(...plan.position);
        world.groups.get(plan.floor).add(group);
        const housing = new THREE.Mesh(new THREE.BoxGeometry(.42, .22, .32), new THREE.MeshStandardMaterial({ color: '#202b28', roughness: .45, metalness: .65 }));
        housing.position.y = .02;
        group.add(housing);
        const lens = new THREE.Mesh(new THREE.SphereGeometry(.075, 12, 8), new THREE.MeshBasicMaterial({ color: '#ff6e62' }));
        lens.position.set(0, -.015, -.17);
        group.add(lens);
        const cone = new THREE.Mesh(new THREE.ConeGeometry(3.3, plan.range, 24, 1, true), new THREE.MeshBasicMaterial({
            color: '#ff554d', transparent: true, opacity: .085, depthWrite: false, side: THREE.DoubleSide,
        }));
        cone.userData.sensorOverlay = true;
        cone.position.set(0, 0, 0);
        world.groups.get(plan.floor).add(cone);
        cone.position.set(...plan.position);
        const sensor = { ...plan, group, lens, cone, currentYaw: plan.yaw };
        return sensor;
    });
    let jamRemaining = 0;
    const ray = new THREE.Vector3();
    const forward = new THREE.Vector3();
    const point = new THREE.Vector3();

    function visible(sensor, playerPosition) {
        if (Math.abs(playerPosition.y - sensor.position[1]) > 3.8) return false;
        ray.set(playerPosition.x - sensor.position[0], playerPosition.y + .9 - sensor.position[1], playerPosition.z - sensor.position[2]);
        const distance = ray.length();
        if (distance > sensor.range || distance < 1.1) return false;
        ray.normalize();
        forward.set(Math.sin(sensor.currentYaw), 0, -Math.cos(sensor.currentYaw));
        if (forward.dot(ray) < Math.cos(sensor.fov)) return false;
        // Sample the view ray against the same collision boxes that block the robber.
        const samples = Math.ceil(distance / .45);
        for (let step = 1; step < samples; step++) {
            const t = step / samples;
            point.set(
                sensor.position[0] + (playerPosition.x - sensor.position[0]) * t,
                sensor.position[1] + (playerPosition.y + .9 - sensor.position[1]) * t,
                sensor.position[2] + (playerPosition.z - sensor.position[2]) * t,
            );
            if (world.colliders.some(collider => overlapsCollider(point, collider, .055, .10))) return false;
        }
        return true;
    }

    return {
        sensors,
        get jammed() { return jamRemaining > 0; },
        get jamSeconds() { return jamRemaining; },
        jam(seconds = 12) { jamRemaining = Math.max(jamRemaining, seconds); },
        update(dt, elapsed, playerPosition, onSpotted) {
            jamRemaining = Math.max(0, jamRemaining - dt);
            for (const sensor of sensors) {
                sensor.currentYaw = sensor.yaw + Math.sin(elapsed * .68 + sensor.phase) * sensor.sweep;
                const direction = forward.set(Math.sin(sensor.currentYaw), 0, -Math.cos(sensor.currentYaw));
                sensor.group.rotation.y = sensor.currentYaw;
                sensor.cone.position.set(...sensor.position).addScaledVector(direction, sensor.range / 2);
                sensor.cone.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.clone().negate());
                sensor.lens.material.color.set(this.jammed ? '#80d7d2' : '#ff6e62');
                sensor.cone.material.color.set(this.jammed ? '#80d7d2' : '#ff554d');
                sensor.cone.material.opacity = this.jammed ? .025 : .075;
                if (!this.jammed && visible(sensor, playerPosition)) onSpotted(sensor);
            }
        },
    };
}

export { CAMERA_PLAN };
