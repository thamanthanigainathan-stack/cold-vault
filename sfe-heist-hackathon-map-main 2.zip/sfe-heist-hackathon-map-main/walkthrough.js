import * as THREE from './vendor/three.module.js';
import { createController, createLighting, createLightingPass, createWorld, ELEVATOR, ELEVATOR_CALL, FLOORS, floorAt } from './map.js';
import { createSecurityNetwork } from './core/security.js';

const canvas = document.querySelector('#world');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
renderer.localClippingEnabled = true;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.shadowMap.autoUpdate = false;

const scene = new THREE.Scene();
scene.background = new THREE.Color('#b8c7cf');
scene.fog = new THREE.Fog('#b8c7cf', 145, 410);
const camera = new THREE.PerspectiveCamera(72, 1, .08, 420);
const world = createWorld(scene);
const security = createSecurityNetwork(world);
const lighting = createLighting(scene, renderer);
const lightingPass = createLightingPass(renderer, camera);
renderer.shadowMap.needsUpdate = true;

const ui = {
    screen: document.querySelector('#screen'), briefing: document.querySelector('#briefing'), result: document.querySelector('#result'),
    start: document.querySelector('#startButton'), retry: document.querySelector('#retryButton'), hud: document.querySelector('#hud'),
    clock: document.querySelector('#clock'), heat: document.querySelector('#heat'), heatChip: document.querySelector('#heatChip'),
    mission: document.querySelector('#missionText'), step: document.querySelector('#routeStep'), ghost: document.querySelector('#ghostText'),
    ghostUse: document.querySelector('#ghostUse'), radar: document.querySelector('#radar'), hint: document.querySelector('#hint'),
    toast: document.querySelector('#toast'), alarm: document.querySelector('#alarmWash'),
    resultEyebrow: document.querySelector('#resultEyebrow'), resultTitle: document.querySelector('#resultTitle'), resultText: document.querySelector('#resultText'),
};
const run = { state: 'menu', timeLeft: 240, heat: 0, elapsed: 0, ghostLinked: false, charges: 0, toastRemaining: 0, wonClean: false };
let player;
const lastPlayerPosition = new THREE.Vector3();

function addConsole() {
    const group = world.groups.get('L1');
    const screen = new THREE.Group();
    screen.name = 'Ghostline security console';
    screen.position.set(12.1, .0, -7.45);
    group.add(screen);
    const metal = new THREE.MeshStandardMaterial({ color: '#26332f', roughness: .5, metalness: .45 });
    const face = new THREE.MeshStandardMaterial({ color: '#112522', emissive: '#0a3432', emissiveIntensity: 1.5, roughness: .3, metalness: .18 });
    const box = (w, h, d, x, y, z, material) => {
        const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
        mesh.position.set(x, y, z); mesh.castShadow = true; mesh.receiveShadow = true; screen.add(mesh); return mesh;
    };
    box(1.65, .76, .76, 0, .38, 0, metal);
    box(1.5, .66, .07, 0, 1.13, -.12, metal);
    box(1.34, .50, .025, 0, 1.15, -.075, face);
    box(.10, .035, .025, -.47, 1.28, -.055, new THREE.MeshBasicMaterial({ color: '#c3f06d' }));
    const glow = new THREE.PointLight('#73d8d0', .7, 3);
    glow.position.set(0, 1.45, -.2); screen.add(glow);
}
addConsole();

function floorLabel(y) { return floorAt(y).id; }
function horizontalDistance(position, x, z) { return Math.hypot(position.x - x, position.z - z); }
function inLift() {
    const { min, max } = ELEVATOR.bounds;
    const { x, y, z } = player.position;
    return Math.abs(x) < max[0] - .35 && z > min[2] + .35 && z < max[2] - .35 && Math.abs(y - world.lift.y) < .22;
}

function showToast(message, duration = 2.5) {
    ui.toast.textContent = message;
    ui.toast.classList.add('show');
    run.toastRemaining = duration;
}

function closestDoor(position, direction) {
    const { x, y, z } = position;
    let nearest;
    for (const door of world.doors.values()) {
        const d = door.definition;
        const [doorX, doorY, doorZ] = d.position;
        if (Math.abs(y - doorY) > .8 || door.moving) continue;
        const half = d.width / 2;
        const dx = (d.axis === 'x' ? THREE.MathUtils.clamp(x, doorX - half, doorX + half) : doorX) - x;
        const dz = (d.axis === 'z' ? THREE.MathUtils.clamp(z, doorZ - half, doorZ + half) : doorZ) - z;
        const distance = Math.hypot(dx, dz);
        if (distance > 2.7 || (distance > .2 && direction.x * dx + direction.z * dz < .26 * distance)) continue;
        if (!nearest || distance < nearest.distance) nearest = { door, distance };
    }
    return nearest;
}

function interact({ position, direction }) {
    if (run.state !== 'running' || world.lift.moving || inLift()) return;
    const floor = floorLabel(position.y);
    if (!run.ghostLinked && floor === 'L1' && horizontalDistance(position, 12.1, -7.45) < 2.7) {
        run.ghostLinked = true;
        run.charges = 2;
        ui.ghost.innerHTML = '<strong>LINKED.</strong> Sensor sweeps are live on your radar.';
        ui.ghostUse.innerHTML = '<strong>Q</strong> Loop all feeds for 12 sec · 2 charges';
        showToast('GHOSTLINE LINKED // SENSOR MAP ACQUIRED');
        return;
    }

    const assetPosition = world.asset.position;
    if (floor === 'B1' && horizontalDistance(position, assetPosition.x, assetPosition.z) < 2.1 &&
        Math.abs(position.y - assetPosition.y) < 1.9) {
        const vault = world.doors.get('B1-vault-door');
        if (!vault.open || vault.progress < .96) {
            showToast('THE RESERVE DOOR IS STILL SEALED.');
        } else {
            finishRun(true);
        }
        return;
    }

    const nearest = closestDoor(position, direction);
    const front = Math.min(Math.hypot(position.x, position.z - ELEVATOR.bounds.max[2]),
        Math.hypot(position.x - ELEVATOR_CALL[0], position.z - ELEVATOR_CALL[1]));
    const rear = Math.hypot(position.x - 1.63, position.z - ELEVATOR.bounds.min[2]);
    const call = front < 2 && position.z > ELEVATOR.bounds.max[2] && direction.z < -.25 ? front
        : floor === 'B1' && rear < 2.1 && position.z < ELEVATOR.bounds.min[2] && direction.z > .25 ? rear : Infinity;
    if (Math.abs(position.y - floorAt(position.y).y) < .4 && call < (nearest?.distance ?? Infinity)) {
        world.lift.moveTo(floorAt(position.y).y);
        showToast('LIFT CALLED // SELECT 1, 2 OR 3 INSIDE');
    } else if (nearest) {
        const opened = nearest.door.setOpen(!nearest.door.open);
        if (!opened && nearest.door.locked) showToast('ACCESS DENIED // SECURITY LOCK IS ACTIVE');
        else if (nearest.door.definition.kind === 'vault') showToast(nearest.door.open ? 'RESERVE DOOR OPEN' : 'RESERVE DOOR CLOSING');
    } else {
        showToast('NOTHING IN REACH // MOVE CLOSER AND FACE IT', 1.6);
    }
}

player = createController({
    camera, domElement: canvas, colliders: world.colliders, supports: world.supports,
    onInteract: interact,
    onLockChange(locked, details = {}) {
        if (run.state !== 'running') return;
        if (!locked && !details.fallback && !document.hidden) showPause();
    },
});
world.player = player;
player.setEnabled(false);

function showPause() {
    if (run.state !== 'running') return;
    run.state = 'paused';
    ui.briefing.classList.remove('hidden');
    ui.result.classList.add('hidden');
    ui.screen.classList.remove('hidden');
    ui.briefing.querySelector('.eyebrow').textContent = 'OPERATION PAUSED';
    ui.briefing.querySelector('h1').innerHTML = 'CATCH<br><em>YOUR BREATH</em>';
    ui.briefing.querySelector('p:not(.fine)').textContent = 'The clock stops while you plan. Your trace level and Ghostline charges are waiting where you left them.';
    ui.start.textContent = 'Resume the heist  →';
}

function restoreBriefing() {
    ui.briefing.querySelector('.eyebrow').textContent = 'FOUNDRY NATIONAL BANK // NIGHT SHIFT';
    ui.briefing.querySelector('h1').innerHTML = 'COLD<br><em>VAULT</em>';
    ui.briefing.querySelector('p:not(.fine)').textContent = 'One clean entry. Three floors. A security network watching every shortcut. Get inside, reach the basement vault, and lift the Foundry Core before the trace closes around you.';
    ui.start.textContent = 'Start hardest run  →';
}

function startRun() {
    if (run.state === 'menu') {
        run.state = 'running';
        ui.hud.classList.remove('hidden');
        ui.briefing.classList.add('hidden');
        ui.screen.classList.add('hidden');
        player.setPosition([0, 0, 25], 0);
        lastPlayerPosition.copy(player.position);
        player.setEnabled(true);
    } else if (run.state === 'paused') {
        run.state = 'running';
        ui.screen.classList.add('hidden');
        restoreBriefing();
        player.setEnabled(true);
    }
    player.lock();
}

function finishRun(success) {
    if (!['running', 'paused'].includes(run.state)) return;
    run.state = success ? 'won' : 'lost';
    player.setEnabled(false);
    ui.screen.classList.remove('hidden');
    ui.briefing.classList.add('hidden');
    ui.result.classList.remove('hidden');
    if (success) {
        ui.resultEyebrow.textContent = run.heat < 35 ? 'GHOST RUN // COMPLETE' : 'HEIST COMPLETE';
        ui.resultTitle.textContent = run.heat < 35 ? 'CLEAN GETAWAY.' : 'THE CORE IS YOURS.';
        ui.resultText.textContent = `You escaped with the Foundry Core and ${Math.ceil(run.timeLeft)} seconds left. Trace level: ${Math.round(run.heat)}%.${run.heat < 35 ? ' The bank never knew what hit it.' : ' The cameras got a look, but you made it.'}`;
    } else {
        ui.resultEyebrow.textContent = 'RUN ENDED';
        ui.resultTitle.textContent = 'THE TRACE CLOSED.';
        ui.resultText.textContent = 'Security has your route. Reset the run, use the bank layout to plan a different path, and try Ghostline when you reach Operations.';
    }
    document.exitPointerLock?.();
}

function useGhostline(event) {
    if (event.code !== 'KeyQ' || event.repeat || run.state !== 'running' || !run.ghostLinked) return;
    if (run.charges < 1) { showToast('GHOSTLINE EMPTY // NO LOOP CHARGES LEFT', 1.8); return; }
    run.charges--;
    security.jam(12);
    ui.ghostUse.innerHTML = `<strong>Q</strong> Loop all feeds for 12 sec · ${run.charges} charge${run.charges === 1 ? '' : 's'}`;
    showToast('GHOSTLINE PULSE // FEEDS LOOPED FOR 12 SECONDS');
}

function selectLiftFloor(event) {
    const match = /^(?:Digit|Numpad)([123])$/.exec(event.code);
    if (!match || event.repeat || run.state !== 'running' || !inLift()) return;
    const destination = FLOORS[Number(match[1]) - 1];
    if (Math.abs(world.lift.y - destination.y) > .05 && world.lift.moveTo(destination.y, true)) player.setEnabled(false);
}

function updateRadar() {
    if (!run.ghostLinked) return;
    ui.radar.querySelectorAll('.blip').forEach(node => node.remove());
    const p = player.position;
    for (const sensor of security.sensors) {
        if (Math.abs(p.y - sensor.position[1]) > 4.8) continue;
        const dx = sensor.position[0] - p.x, dz = sensor.position[2] - p.z;
        if (Math.hypot(dx, dz) > 29) continue;
        const blip = document.createElement('i');
        blip.className = 'blip';
        blip.style.left = `${THREE.MathUtils.clamp(50 + dx * 1.45, 8, 92)}%`;
        blip.style.top = `${THREE.MathUtils.clamp(50 + dz * 1.45, 8, 92)}%`;
        if (security.jammed) { blip.style.background = '#80d7d2'; blip.style.boxShadow = '0 0 10px #80d7d2'; }
        ui.radar.append(blip);
    }
}

function updateObjective() {
    if (run.state !== 'running') return;
    const p = player.position;
    const floor = floorLabel(p.y);
    const outside = p.z > 19 || Math.abs(p.x) > 26;
    if (outside) {
        ui.step.textContent = '01 / Enter through the main doors';
        ui.mission.textContent = 'Get inside. The bank is watching the public entrance.';
    } else if (floor === 'L1' && !run.ghostLinked) {
        ui.step.textContent = '02 / Find Operations (optional)';
        ui.mission.textContent = 'The vault is below. Ghostline is in the east Operations office if you want to map and loop the cameras.';
    } else if (floor !== 'B1') {
        ui.step.textContent = run.ghostLinked ? '02 / Reach the basement' : '02 / Find a way to B1';
        ui.mission.textContent = 'Reach the basement. Use the central lift or the west/east stairs.';
    } else if (p.z > -10) {
        ui.step.textContent = '03 / Cross the reserve approach';
        ui.mission.textContent = 'The Central Reserve is ahead. Reach its round door and press E.';
    } else {
        ui.step.textContent = '04 / Open the vault and take the Core';
        ui.mission.textContent = 'The Foundry Core is on the plinth behind the vault door. Get close and press E.';
    }
}

function updateHint() {
    if (run.state !== 'running') return;
    if (!player.locked && !player.fallback) { ui.hint.innerHTML = 'CLICK THE MAP TO LOOK AROUND'; return; }
    const p = player.position;
    if (!run.ghostLinked && floorLabel(p.y) === 'L1' && horizontalDistance(p, 12.1, -7.45) < 3.2) {
        ui.hint.innerHTML = '<kbd>E</kbd> LINK GHOSTLINE // SECURITY OPERATIONS'; return;
    }
    const target = new THREE.Vector3(); camera.getWorldDirection(target);
    const nearest = closestDoor(p, target);
    const assetPos = world.asset.position;
    if (floorLabel(p.y) === 'B1' && horizontalDistance(p, assetPos.x, assetPos.z) < 2.4 && Math.abs(p.y - assetPos.y) < 1.9) {
        ui.hint.innerHTML = '<kbd>E</kbd> TAKE THE FOUNDRY CORE'; return;
    }
    if (nearest) {
        const label = nearest.door.definition.kind === 'vault' ? (nearest.door.open ? 'CLOSE RESERVE DOOR' : 'OPEN CENTRAL RESERVE') : (nearest.door.open ? 'CLOSE DOOR' : 'OPEN DOOR');
        ui.hint.innerHTML = `<kbd>E</kbd> ${label}`; return;
    }
    ui.hint.innerHTML = '<kbd>WASD</kbd> MOVE&nbsp; <kbd>SHIFT</kbd> SPRINT&nbsp; <kbd>E</kbd> INTERACT&nbsp; <kbd>Q</kbd> GHOSTLINE&nbsp; <kbd>ESC</kbd> PAUSE';
}

function updateGame(dt) {
    if (run.state !== 'running') return;
    run.timeLeft = Math.max(0, run.timeLeft - dt);
    if (run.timeLeft <= 0) { finishRun(false); return; }
    const moved = player.position.distanceTo(lastPlayerPosition);
    const sprinting = dt > 0 && moved / dt > 5.6;
    lastPlayerPosition.copy(player.position);
    // Sprinting is faster, but its noise leaves a faint trace even outside camera view.
    run.heat = THREE.MathUtils.clamp(run.heat - dt * 2.2 + (sprinting ? dt * 2.8 : 0), 0, 100);
    security.update(dt, run.elapsed, player.position, () => { run.heat = Math.min(100, run.heat + dt * 5.2); });
    if (run.heat >= 100) { finishRun(false); return; }
    ui.clock.textContent = `${String(Math.floor(run.timeLeft / 60)).padStart(2, '0')}:${String(Math.floor(run.timeLeft % 60)).padStart(2, '0')}`;
    ui.heat.textContent = `${String(Math.round(run.heat)).padStart(2, '0')}%`;
    ui.heatChip.classList.toggle('alert', run.heat > 58);
    ui.alarm.classList.toggle('hot', run.heat > 72);
    if (security.jammed) ui.ghost.innerHTML = `<strong>FEED LOOP ACTIVE.</strong> ${Math.ceil(security.jamSeconds)} sec window.`;
    else if (run.ghostLinked) ui.ghost.innerHTML = '<strong>LINKED.</strong> Sensor sweeps are live on your radar.';
    run.toastRemaining = Math.max(0, run.toastRemaining - dt);
    if (run.toastRemaining <= 0) ui.toast.classList.remove('show');
    updateRadar(); updateObjective(); updateHint();
}

function resize() {
    renderer.setPixelRatio(Math.min(devicePixelRatio, 1.6));
    renderer.setSize(innerWidth, innerHeight, false);
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    lightingPass.resize();
}

const captureMouse = () => { if (run.state === 'running') player.lock(); };
canvas.addEventListener('click', captureMouse);
ui.start.addEventListener('click', startRun);
ui.retry.addEventListener('click', () => location.reload());
window.addEventListener('keydown', selectLiftFloor);
window.addEventListener('keydown', useGhostline);
window.addEventListener('resize', resize);
resize();

let previous = performance.now();
renderer.setAnimationLoop(now => {
    let remaining = Math.min((now - previous) / 1000, .25);
    previous = now;
    while (remaining > .00001) {
        const dt = Math.min(.05, remaining);
        if (run.state === 'running') run.elapsed += dt;
        const riding = world.lift.moving && world.lift.passenger;
        world.update(dt, run.elapsed, player);
        if (riding) {
            player.setPosition(player.position);
            if (!world.lift.moving) player.setEnabled(true);
        } else player.update(dt);
        updateGame(dt);
        remaining -= dt;
    }
    lighting.update(camera.position);
    lightingPass.render(scene);
});

window.addEventListener('pagehide', event => {
    if (event.persisted) return;
    renderer.setAnimationLoop(null);
    canvas.removeEventListener('click', captureMouse);
    ui.start.removeEventListener('click', startRun);
    window.removeEventListener('keydown', selectLiftFloor);
    window.removeEventListener('keydown', useGhostline);
    window.removeEventListener('resize', resize);
    player.dispose();
    lightingPass.dispose();
    lighting.dispose();
    world.dispose();
    renderer.dispose();
});
